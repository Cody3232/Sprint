import React from 'react';

function Footer() {
  return (
    <footer style={{ textAlign: 'center', padding: '1rem', background: '#f4f4f4', marginTop: '2rem' }}>
      <p style={{ color: 'black' }}>© 2024 ProductDetails Inc. All Rights Reserved.</p>
      <p>
        <a href="/privacy-policy">Privacy Policy</a> | <a href="/terms">Terms of Service</a>
      </p>
    </footer>
  );
}

export default Footer;
