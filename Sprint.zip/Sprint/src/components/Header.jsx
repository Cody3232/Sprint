import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', background: '#1a1a1a', color: '#fff' }}>
      {/* Logo Section */}
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img 
          src="/photos/logo.png" 
          alt="ElectraMart Logo" 
          style={{ width: '50px', height: '50px', marginRight: '1rem' }}
        />
        <Link to="/" style={{ color: '#d78a3c', textDecoration: 'none', fontSize: '1.5rem', fontWeight: 'bold' }}>ElectraMart</Link>
      </div>

      {/* Navigation Section */}
      <nav style={{ display: 'flex', justifyContent: 'end', flexGrow: 1 }}>
        <Link to="/" style={{ margin: '0 1rem', color: '#fff', textDecoration: 'none' }}>Home</Link>
        <Link to="/cart" style={{ margin: '0 1rem', color: '#fff', textDecoration: 'none' }}>Cart</Link>
        <Link to="/checkout" style={{ margin: '0 1rem', color: '#fff', textDecoration: 'none' }}>Checkout</Link>
      </nav>
    </header>
  );
}

export default Header;
