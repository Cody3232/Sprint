import React from 'react';

function Cart({ cart, removeFromCart, updateQuantity }) {
  // Calculate total price
  const totalPrice = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // Handle quantity changes
  const handleQuantityChange = (id, newQuantity) => {
    if (newQuantity >= 0) {
      updateQuantity(id, newQuantity);
    }
  };

  return (
    <div>
      <h1>Shopping Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          <ul>
            {cart.map((item) => (
              <li key={item.id} style={{ marginBottom: '20px' }}>
                <p>{item.name}</p>
                <p>Price: ${item.price.toFixed(2)}</p>
                <p>
                  Quantity:
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) =>
                      handleQuantityChange(item.id, parseInt(e.target.value, 10) || 0)
                    }
                    min="0"
                    style={{ width: '50px', marginLeft: '10px' }}
                  />
                </p>
                <button onClick={() => removeFromCart(item.id)}>Remove</button>
              </li>
            ))}
          </ul>
          <p>Total: ${totalPrice.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}

export default Cart;
