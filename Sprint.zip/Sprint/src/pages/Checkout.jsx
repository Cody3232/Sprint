import React, { useState } from 'react';
import '../styles/Checkout.css';

function Checkout({ cart, clearCart }) {
  const [userInfo, setUserInfo] = useState({
    name: '',
    email: '',
    address: '',
    phone: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserInfo((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);
    clearCart();
    console.log('User Info:', userInfo); 

    
    setTimeout(() => {
      setIsSubmitted(false); // Reset the form or perform any further actions
    }, 5000); 
  };

  return (
    <div className="cart-container">
      <h1>Your Checkout</h1>
      <p>Proceed to complete your purchase.</p>
      {cart.length === 0 ? (
        <p>Your cart is empty. Add items to your cart to proceed.</p>
      ) : (
        <>
          <form onSubmit={handleSubmit} className="checkout-form">
            <div className="form-group">
              <label htmlFor="name">Name:</label>
              <input
                id="name"
                className="form-control"
                type="text"
                name="name"
                value={userInfo.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                id="email"
                className="form-control"
                type="email"
                name="email"
                value={userInfo.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="address">Address:</label>
              <textarea
                id="address"
                className="form-control"
                name="address"
                value={userInfo.address}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="phone">Phone:</label>
              <input
                id="phone"
                className="form-control"
                type="tel"
                name="phone"
                value={userInfo.phone}
                onChange={handleChange}
                required
              />
            </div>
            <button type="submit" className="checkout-button">
              Complete Purchase
            </button>
          </form>

          {isSubmitted && (
            <div className="thank-you-message">
              <h2>Thank you for your purchase, {userInfo.name}!</h2>
              <p>We will send a confirmation email to {userInfo.email}.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default Checkout;
