import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import '../styles/ProductDetails.css';

function ProductDetails({ addToCart }) {
  const { id } = useParams(); // Get the product ID from the URL
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cartNotification, setCartNotification] = useState(false); // State for notification

  useEffect(() => {
    // Fetch the product from the backend using the product ID
    fetch(`http://localhost:5001/products/${id}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Product not found');
        }
        return response.json();
      })
      .then((data) => {
        setProduct(data); // Update the product state with fetched data
        setLoading(false); // Set loading to false once data is fetched
      })
      .catch((error) => {
        console.error('Error fetching product:', error);
        setLoading(false); // Set loading to false even in case of error
      });
  }, [id]); // This effect runs every time the product ID in the URL changes

  const updateProductQuantity = async (productId, newQuantity) => {
    try {
      await fetch(`http://localhost:5001/products/${productId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ quantity: newQuantity }),
      });
    } catch (error) {
      console.error('Error updating product quantity:', error);
    }
  };

  // Handle adding product to the cart and updating the quantity
  const handleAddToCart = (product) => {
    if (product.quantity > 0) {
      addToCart(product); // Add product to cart
      const newQuantity = product.quantity - 1;
      setProduct((prevProduct) => ({ ...prevProduct, quantity: newQuantity })); // Update local state
      updateProductQuantity(product.id, newQuantity); 
      setCartNotification(true); // Show notification

      // Hide the notification after 3 seconds
      setTimeout(() => {
        setCartNotification(false);
      }, 3000);
    } else {
      alert('Product is out of stock!'); // Notify user if out of stock
    }
  };

  if (loading) {
    return <div>Loading...</div>; 
  }

  if (!product) {
    return (
      <div>
        <h2>Product not found</h2>
        <Link to="/">Return to Home</Link>
      </div>
    ); // Show this if the product is not found or an error occurs
  }

  return (
    <div className="product-details">
      <h1>{product.name}</h1>
      <img src={product.image} alt={product.name} />
      <p>{product.description}</p>
      <p>Price: ${product.price}</p>
      <p>Available Quantity: {product.quantity}</p>
      <button onClick={() => handleAddToCart(product)}>Add to Cart</button>
      <br />
      <Link to="/">Back to Home</Link>

      {/* Cart Notification */}
      {cartNotification && (
        <div style={notificationStyles}>
          <p>Item added to cart!</p>
        </div>
      )}
    </div>
  );
}

// Basic styles for the cart notification
const notificationStyles = {
  position: 'fixed',
  top: '7px',
  right: '7px',
  backgroundColor: '#d78a3c',
  color: '#fff',
  padding: '10px',
  borderRadius: '100px',
  fontSize: '1rem',
  zIndex: '1000',
};

export default ProductDetails;
